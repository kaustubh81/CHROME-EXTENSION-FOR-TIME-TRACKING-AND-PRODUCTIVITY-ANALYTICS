chrome.storage.local.get(["usage", "productive", "unproductive", "uncategorized"], (data) => {
  const usage = data.usage || {};
  const usageList = document.getElementById("usage");
  const summaryDiv = document.getElementById("summary");

  for (const domain in usage) {
    const minutes = Math.round(usage[domain] / 60000);
    const li = document.createElement("li");
    li.textContent = `${domain}: ${minutes} min`;
    usageList.appendChild(li);
  }

  summaryDiv.innerHTML = `
    <p><strong>Productive:</strong> ${Math.round((data.productive || 0) / 60000)} min</p>
    <p><strong>Unproductive:</strong> ${Math.round((data.unproductive || 0) / 60000)} min</p>
    <p><strong>Uncategorized:</strong> ${Math.round((data.uncategorized || 0) / 60000)} min</p>
  `;
});
