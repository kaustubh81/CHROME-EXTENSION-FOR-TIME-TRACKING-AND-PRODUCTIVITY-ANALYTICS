let currentTabId = null;
let currentDomain = null;
let startTime = null;

const productiveSites = ['leetcode.com', 'github.com', 'stackoverflow.com', 'w3schools.com'];
const unproductiveSites = ['facebook.com', 'instagram.com', 'youtube.com', 'tiktok.com'];

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  await logTime();
  const tab = await chrome.tabs.get(activeInfo.tabId);
  if (tab.url.startsWith('chrome://')) return;
  currentDomain = new URL(tab.url).hostname;
  startTime = Date.now();
  currentTabId = activeInfo.tabId;
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (tab.active && changeInfo.url) {
    await logTime();
    if (tab.url.startsWith('chrome://')) return;
    currentDomain = new URL(tab.url).hostname;
    startTime = Date.now();
  }
});

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  await logTime();
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    currentDomain = null;
  } else {
    chrome.tabs.query({ active: true, windowId }, (tabs) => {
      if (tabs.length > 0 && tabs[0].url && !tabs[0].url.startsWith('chrome://')) {
        currentDomain = new URL(tabs[0].url).hostname;
        startTime = Date.now();
      }
    });
  }
});

async function logTime() {
  if (currentDomain && startTime) {
    const duration = Date.now() - startTime;

    let data = await chrome.storage.local.get(["usage", "productive", "unproductive", "uncategorized"]) || {};
    data.usage = data.usage || {};
    data.usage[currentDomain] = (data.usage[currentDomain] || 0) + duration;

    if (productiveSites.includes(currentDomain)) {
      data.productive = (data.productive || 0) + duration;
    } else if (unproductiveSites.includes(currentDomain)) {
      data.unproductive = (data.unproductive || 0) + duration;
    } else {
      data.uncategorized = (data.uncategorized || 0) + duration;
    }

    await chrome.storage.local.set(data);
  }
}
